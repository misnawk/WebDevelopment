package dialog;




public class Main {

	
	public static void main(String[] args) {
				try {
					DialogFrom dialog = new DialogFrom();
			
					
					DialogHandler dialogHandler = new DialogHandler();
					dialogHandler.messageReceived();
				
					
				} catch (Exception e) {
					e.printStackTrace();
				}
	
	}
}
