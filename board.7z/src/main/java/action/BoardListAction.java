package action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import dao.BoardDAO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.Common.Board;
import vo.BoardVO;

@WebServlet("/board_list")
public class BoardListAction extends HttpServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int nowPage = 1;
		//start부터 end까지만 조회해라
		String page = request.getParameter("page");
		
		if(page != null && !page.isEmpty()) {
			nowPage = Integer.parseInt(page);
		}
		
		//page가 1이면 등수 1~10까지 조회
		//페이지가 2이면 등수 11~20까지 조회되야함
		int start = (nowPage - 1) * Board.BLOCKLIST + 1; 
		int end = start + Board.BLOCKLIST - 1;
		
		HashMap<String, Integer> map = new HashMap<>();
		map.put("start", start);
		map.put("end", end);
	
		//전체 목록 가져오기
		List<BoardVO> list = BoardDAO.getInstance().selectList(map); //BoardDao를 사용해서 게시판 전체 목록조회
		
		//전체 게시물 수 조회
		int rowTotal = BoardDAO.getInstance().getRowTotal();

		// 페이지 메뉴 생성하기
		String pageMenu = Page.getPaging("board_list", 
												nowPage,
												rowTotal, 
												Board.BLOCKLIST, 
												Board.BLOCKPAGE);

		request.getSession().removeAttribute("show"); //세션에서 show 속성 제거
		
		//list객체를 list으로 지정해준다. 
		//JSP 페이지에서 사용할수있다.
		request.setAttribute("list", list); 
		request.setAttribute("pageMenu", pageMenu); 
		
		//포워딩이란?
		//서버측에서 클라이언트의 요청을 다른 리소스로 넘기는 작업.
		
		//RequestDispatcher?
		//다른 파일로 요청을 전달하거나 포함 할수 있게 해주는 인터페이스
		RequestDispatcher disp = request.getRequestDispatcher("board_list.jsp");
		disp.forward(request, response);
	}
}
