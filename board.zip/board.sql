--시퀀스
SELECT * FROM board;
ALTER TABLE BOARD add(del_info NUMBER(2));

DELETE  table board WHERE idx=22; 



create sequence seq_board_idx;

select * from (select rank() over(order by ref desc, step) no, b.* from board b) where no between 1 and 10;


--테이블
create table board(
	idx number(3) primary key,
	name varchar2(100) not null,
	subject varchar2(255) not null,
	content clob,
	pws varchar2(100),
	IP varchar2(100),
	regdate date,
	readhit number(3) default 0,
	--계층형 게시판을 운영하기 위한 추가정보
	ref number, --기준글 번호(답글이 달리는 메인글)
	step number, --답글순서
	depth number -- 답글의 깊이
);


-- 샘플데이터
insert into board Values(
	seq_board_idx.nextval,
	'이름-일길동',
	'제목-내가일등',
	'내용-내가일등',
	'1234',
	'192.0.0.1',
	sysdate,
	0,
	seq_board_idx.currval,
	0,
	0
);
--답글
insert into board Values(
	seq_board_idx.nextval,
	'이름-일길동',
	'제목-집가고싶다',
	'내용-집',
	'1234',
	'192.0.0.1',
	sysdate,
	0,
	1, --메인글의 idx
	1, --step
	1  --depth
);

--답글의 답글
insert into board Values(
	seq_board_idx.nextval,
	'이름-일길동',
	'제목-집가고싶다',
	'내용-집',
	'1234',
	'192.0.0.1',
	sysdate, 
	0,
	1, 
	2, 
	2
);
