package action;

public class Page {
    // 현재페이지
    // 전체 데이터의 개수
    // 한 페이지당 게시물 수
    // 한 화면에 나타날 페이지 메뉴 수 <- 1 2 3 ->
	
	public static String getPaging(String pageURL, int nowPage, int rowTotal, int blockList, int blockPage) {
		int totalPage;
		int startPage;
		int endPage;
		
		boolean isPrevPage, isNextPage;
		StringBuffer sb;
	
		isPrevPage = isNextPage = false;
		
		totalPage = rowTotal / blockList;
	
		// 한 페이지에 10개를 보여주는 페이지 생성함
		// 하지만 게시물이 41개라면 4페이지에다가 +1 페이지를 해준다.
		if(rowTotal % blockList != 0) totalPage++; 
		
		// 만약 잘못된 연산과 움직임으로 인하여 현재 페이지수가 전체 페이지 수를
		// 넘었을 경우 강제로 현재 페이지 값을 전체 페이지 값으로 변경
		if(nowPage > totalPage) nowPage = totalPage;
		
		// 시작페이지와 마지막 페이지를 구한다.
		startPage = ((nowPage - 1) / blockPage) * blockPage + 1;
		endPage = startPage + blockPage - 1;
		
		// 마지막 페이지 수가 전체 페이지 수보다 크면 마지막 페이지 값을 변경
		if(endPage > totalPage) endPage = totalPage;
		
		// 마지막 페이지가 전체 페이지보다 작을 경우 다음 페이징이 적용될 수 있도록
		// Boolean형 값을 변경
		if(endPage < totalPage) isNextPage = true;
		
		// 시작페이지의 값이 1보다 크면 이전 페이징이 적용될 수 있도록 값 설정
		if(startPage > 1) isPrevPage = true;
		
		sb = new StringBuffer();
		
		// 그룹페이지처리(이전버튼)----------------------------------------------
		if(isPrevPage) {
			sb.append("<a href='").append(pageURL).append("?page=");
			sb.append(startPage - 1);
			sb.append("'><img src='img/btn_prev.gif'></a>");
		} else {
			sb.append("<img src='img/btn_prev.gif'>");
		}
		
		// 페이지 목록 출력----------------------------------------------------------
		sb.append(" ");
		for(int i = startPage; i <= endPage; i++) { // <= 연산자 사용
			if(i > totalPage) break;
			if(i == nowPage) { // 현재 있는 페이지 색깔 바꾸기
				sb.append("&nbsp;<b><font color='#ff0000'>");
				sb.append(i);
				sb.append("</font></b>");
			} else {
				sb.append("&nbsp;<a href='").append(pageURL).append("?page=").append(i).append("'>");
				sb.append(i);
				sb.append("</a>");
			}
		}
		sb.append("&nbsp;");
		
		
		// 그룹페이지처리(다음버튼)----------------------------------------------
		if(isNextPage) {
			sb.append("<a href='").append(pageURL).append("?page=");
			sb.append(endPage + 1);
			sb.append("'><img src='img/btn_next.gif'></a>");
		} else {
			sb.append("<img src='img/btn_next.gif'>");
		}

		return sb.toString(); // 생성된 페이징 HTML 문자열 반환
	}
}
